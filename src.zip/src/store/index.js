import { configureStore } from "@reduxjs/toolkit";
import HotelSlice from "./Hotel-slice";

const store = configureStore({
  reducer: {
    hotel: HotelSlice.reducer,
  },
});
export default store;

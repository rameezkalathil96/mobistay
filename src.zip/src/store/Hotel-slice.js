import { createSlice } from "@reduxjs/toolkit";
import { v4 as uuidv4 } from "uuid";


const HotelSlice = createSlice({
  name: "hotellist",
  initialState: {
    hotels: [
      {
        hotel_name: "Umaid Bhawan Palace",
        hotel_address1: "Jodpur",
        hotel_address2: "Circuit House Rd,Cantt Area,Rajastan ",
        hotel_review: "Exellent Experience",
        hotel_rating: "4.8",
        hotel_image:
          "https://media.cntraveler.com/photos/594001185fff7e434a15efbe/master/w_1920%2Cc_limit/Exterior-UmaidBhawanPalaceTaj-India-CRHotel.jpg",
        hotel_starting_price: "20000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 20000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "The Leela Palace ",
        hotel_address1: "New Delhi",
        hotel_address2: "Netaji Nagar Rd,Netaji Nagar,Delhi 110023",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/61a905183bd71f2d5e014d1f/master/w_1920%2Cc_limit/The%2520Leela_Lobby_sitting.JPG",
        hotel_starting_price: "30000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "The Oberoi Udaivilas",
        hotel_address1: "Udaipur",
        hotel_address2:
          "Udaipur, Badi-Gorela-Mulla Talai Rd, Haridas Ji Ki Magri, Pichola, Udaipur",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/5c06e5a701ffc86b13da2528/master/w_1920%2Cc_limit/The-Oberoi-Udaivilas%2C-Udaipur__2018_Premier-Lake-View-Rooms-with-Semi-Private-Pools---The-Oberoi-Udaivilas%2C-Udaipur-01.jpg",
        hotel_starting_price: "40000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "The Taj Mahal Palace",
        hotel_address1: "Mumbai",
        hotel_address2: "Mumbai, Apollo Bandar, Colaba, Mumbai, Maharashtra",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/5dee7549d606100008e741f0/master/w_1920%2Cc_limit/The-Taj-Mahal-Palace_2019_Taj-Mahal-Palace%2C-Mumbai---Corridor-1.jpg",
        hotel_starting_price: "35000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "ITC Maurya",
        hotel_address1: "New Delhi",
        hotel_address2: "Akhaura Block, Bapu dham, Chanakyapuri, New Delhi",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/5cb5de7111a45eb388303707/master/w_1920%2Cc_limit/ITC-Maurya%2C-a-Luxury-Collection-Hotel%2C-New-Delhi_2019_Swimming-Pool.jpg",
        hotel_starting_price: "25000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "Rambagh Palace",
        hotel_address1: "Jaipur",
        hotel_address2:
          "Jaipur, VRX5+66Q, Bhawani Singh Rd, Rambagh, Jaipur, Rajasthan",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/5f678a4eb981fb78a3045f9c/master/w_960%2Cc_limit/rambagh-palace-jaipur.jpg",
        hotel_starting_price: "30000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "Taj Lake Palace",
        hotel_address1: " Udaipur",
        hotel_address2: " Pichola, Udaipur, Rajasthan ",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/53d9c4b1dcd5888e1459b47c/master/w_960%2Cc_limit/taj-lake-palace-udaipur-rajasthan-udaipur-india-108677-1.jpg",
        hotel_starting_price: "25000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),
            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "The Lodhi",
        hotel_address1: "New Delhi",
        hotel_address2: "New Delhi, India",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/59de699de8ae802744462390/master/w_960%2Cc_limit/Exterior1-TheLodhi-India-CRHotel.jpg",
        hotel_starting_price: "20000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "Taj Fateh Palace",
        hotel_address1: "Udaipur",
        hotel_address2:
          "Lake Pichola, The City Palace Complex, City Palace Rd, Udaipur, Rajasthan",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/61c983e7361139bfc50b29d5/master/w_960%2Cc_limit/Taj-Fateh-Prakash-Palace.jpg",
        hotel_starting_price: "28000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "JW Marriott Juhu",
        hotel_address1: "Mumbai",
        hotel_address2: "Juhu Tara Rd Mumbai Maharashtra",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/53dacd95dcd5888e145ce2f2/master/w_960%2Cc_limit/jw-marriott-mumbai-mumbai-india-108608-3.jpg",
        hotel_starting_price: "",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
      {
        hotel_name: "SUJÁN The Serai",
        hotel_address1: "Jaisalmer",
        hotel_address2: "Jaisalmer, Rajasthan",
        hotel_review: "",
        hotel_rating: "",
        hotel_image:
          "https://media.cntraveler.com/photos/606de02150f16c474fede587/master/w_960%2Cc_limit/Hotel_Placeholder_Image.jpg",
        hotel_starting_price: "30000",
        hotel_services: [
          "Pool",
          "Free WiFi",
          "Parking included",
          "Air",
          "conditioning",
          "Spa",
          "Restaurant",
        ],
        hotel_room: [
          {
            Room_No: "001",

            Room_Type: "AC",

            Bed_type: "Single",

            Room_Id: uuidv4(),

            Price: 2000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },

          {
            Room_No: "002",

            Room_Type: "NON-AC",

            Bed_type: "Double",

            Room_Id: uuidv4(),

            Price: 3000,

            Image:
              "https://gos3.ibcdn.com/0fe6bcd0343511e98ee30242ac110003.jpg",
          },
        ],
      },
    ],
  },
  reducers: {},
});

export const hotelactions = HotelSlice.actions;

export default HotelSlice;

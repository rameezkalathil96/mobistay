
import React from "react";
import classes from "./nav.module.css";
import { ImLocation2 } from "react-icons/im";
import { FaUserCircle } from "react-icons/fa";
// import { BiLogOut } from "react-icons/bi";
// import { FaRegUser } from "react-icons/fa";

const Nav = () => {
  return (
    <>
      <div>
        <nav className={`navbar ${classes.Nav}`}>
          <div className="container">
            <div>
              {/* <Link to="/" className={classes.Link}> */}
              <h3 className={classes.navLogo}>
                <span className={classes.mobi}>
                  <b>
                    Mobi
                    <ImLocation2 />
                  </b>
                </span>
                <span className={classes.stay}>
                  <b>stay</b>
                </span>
              </h3>
              {/* </Link> */}
            </div>
          </div>
          <div className={classes.usericon}>
            <FaUserCircle />
            <span className={classes.login}>Login/Signup</span>
            {/* <div>
              {" "}
              Hi,user
              <FaRegUser />
              <BiLogOut />
              <span className={classes.login}>Logout</span>
            </div> */}
          </div>
        </nav>
      </div>
    </>
  );
};

export default Nav;
